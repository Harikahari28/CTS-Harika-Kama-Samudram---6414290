import React from 'react';
import Posts from './Posts';

function App() {
  return (
    <div className="App">
      <h1>Welcome to BlogApp</h1>
      <Posts />
    </div>
  );
}

export default App;
